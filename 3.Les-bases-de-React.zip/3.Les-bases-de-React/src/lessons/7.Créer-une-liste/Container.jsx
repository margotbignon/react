export default function Container() {
  return (
    <div>
      <h1>Créer une liste d'éléments avec React</h1>
    </div>
  )
}