export default function Container() {
  return <div>
    <h1>Rendu conditionnel</h1>
  </div>
}
