export default function Container() {
  return (
    <div>
      <h1>Premier Composant</h1>
    </div>
  )
}