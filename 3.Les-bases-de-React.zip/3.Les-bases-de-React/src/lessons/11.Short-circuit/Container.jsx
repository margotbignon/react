export default function Container() {

  return (
    <div>
      <h1>Bienvenue sur BooksParadise</h1>


    </div>
  )
}
