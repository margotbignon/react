import "./Container.css"

export default function Container() {

  return (
    <div>
      <h1>Composants "controlled" et "uncontrolled"</h1>
    </div>
  )
}
