import { useState } from "react"
import "./Container.css"

export default function Container() {
  return (
    <div>
      <h1>Opération ternaire</h1>
      <form></form>
    </div>
  )
}
