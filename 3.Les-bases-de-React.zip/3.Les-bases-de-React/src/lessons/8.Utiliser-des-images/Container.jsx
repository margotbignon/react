export default function Container() {

  return (
    <div>
      <h1>Utiliser des images</h1>

    </div>
  )
}
