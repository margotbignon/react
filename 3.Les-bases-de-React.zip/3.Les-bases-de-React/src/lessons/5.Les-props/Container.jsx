export default function Container() {
  
  return (
    <div>
      <h1>Les props</h1>
    </div>
  )
}
