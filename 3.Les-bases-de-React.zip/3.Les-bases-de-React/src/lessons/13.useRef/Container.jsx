export default function Container() {

  return (
    <div>
      <h1>Comprendre les refs</h1>
    </div>
  )
}
