import "./Container.css"

export default function Container() {
  return (
    <div>
      <h1>Toggle une classe</h1>
    </div>
  )
}
